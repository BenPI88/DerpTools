import os
print("DERPTOOLS V1.0")
print("1: Copy Files")
print("2: Read Text Files")
print("3: Edit Text Files")
print("4: Scan For IP Addresses On Your Local Network")
item = input("Item # Here: ")
if item == "1":
    os.system("clear")
    dest_1 = input("From: ")
    dest_2 = input("To: ")
    os.system("cp " + dest_1 + " " + dest_2)
if item == "2":
    os.system("clear")
    dest_1 = input("File: ")
    os.system("cat " + dest_1)
if item == "3":
    os.system("clear")
    dest_1 = input("File: ")
    os.system("nano " + dest_1)
if item == "4":
    os.system("clear")
    dest_1 = input("IP Address: ")
    os.system("sudo nmap -sn " + dest_1 + "/24")